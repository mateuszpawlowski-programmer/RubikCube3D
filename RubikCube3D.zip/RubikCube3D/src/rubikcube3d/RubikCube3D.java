/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rubikcube3d;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Polygon;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class RubikCube3D extends JPanel implements Runnable,MouseListener,MouseMotionListener,KeyListener,MouseWheelListener{

     public JPanel panel;
     public JFrame frame = new JFrame("RubikCube3D.");
     public Thread thread;
     
     public int angleX=0;
     public int angleY=0;
     
     public int rotator=0;
     public boolean rotating=false;
     public int wall_to_rotate=1;
     public int rot_dir=1;
     
     public int animation=0;
     
     public boolean drawFrame=false;
     
     public int old_mouse_x,old_mouse_y;
     public int mouse_speed_x=3,mouse_speed_y=3;
     public double WorldX=20,WorldY=60;
     public static ArrayList<Triangle> tlist=new ArrayList<Triangle>();
     public static ArrayList<Triangle> tlist_org=new ArrayList<Triangle>();
     
    RubikCube3D()
    {
    this.addMouseMotionListener(this);
    this.addMouseListener(this);
    this.addKeyListener(this);
    this.addMouseWheelListener(this);
    
    setFocusable(true);
    setFocusTraversalKeysEnabled(false);
    
    Triangle t1=new Triangle(new Point3d(-5,5,-15),new Point3d(5,5,-15),new Point3d(5,-5,-15),new Point3d(-5,-5,-15),new Point3d(0,0,-15));
    Triangle t2=new Triangle(new Point3d(-5-10,5,-15),new Point3d(5-10,5,-15),new Point3d(5-10,-5,-15),new Point3d(-5-10,-5,-15),new Point3d(-10,0,-15));
    Triangle t3=new Triangle(new Point3d(-5+10,5,-15),new Point3d(5+10,5,-15),new Point3d(5+10,-5,-15),new Point3d(-5+10,-5,-15),new Point3d(10,0,-15));
    
    Triangle t4=new Triangle(new Point3d(-5,5+10,-15),new Point3d(5,5+10,-15),new Point3d(5,-5+10,-15),new Point3d(-5,-5+10,-15),new Point3d(0,10,-15));
    Triangle t5=new Triangle(new Point3d(-5-10,5+10,-15),new Point3d(5-10,5+10,-15),new Point3d(5-10,-5+10,-15),new Point3d(-5-10,-5+10,-15),new Point3d(-10,10,-15));
    Triangle t6=new Triangle(new Point3d(-5+10,5+10,-15),new Point3d(5+10,5+10,-15),new Point3d(5+10,-5+10,-15),new Point3d(-5+10,-5+10,-15),new Point3d(10,10,-15));
    
    Triangle t7=new Triangle(new Point3d(-5,5-10,-15),new Point3d(5,5-10,-15),new Point3d(5,-5-10,-15),new Point3d(-5,-5-10,-15),new Point3d(0,-10,-15));
    Triangle t8=new Triangle(new Point3d(-5-10,5-10,-15),new Point3d(5-10,5-10,-15),new Point3d(5-10,-5-10,-15),new Point3d(-5-10,-5-10,-15),new Point3d(-10,-10,-15));
    Triangle t9=new Triangle(new Point3d(-5+10,5-10,-15),new Point3d(5+10,5-10,-15),new Point3d(5+10,-5-10,-15),new Point3d(-5+10,-5-10,-15),new Point3d(10,-10,-15));
    
    t1.tr_color=new Color(255,255,0);t1.nr2=23;
    t2.tr_color=new Color(255,255,0);t2.nr2=22;
    t3.tr_color=new Color(255,255,0);t3.nr2=24;
    
    t4.tr_color=new Color(255,255,0);t4.nr2=26;
    t5.tr_color=new Color(255,255,0);t5.nr2=25;
    t6.tr_color=new Color(255,255,0);t6.nr2=27;
    
    t7.tr_color=new Color(255,255,0);t7.nr2=20;
    t8.tr_color=new Color(255,255,0);t8.nr2=19;
    t9.tr_color=new Color(255,255,0);t9.nr2=21;
    
    t1.tr_color=Color.ORANGE;
    t2.tr_color=Color.ORANGE;
    t3.tr_color=Color.ORANGE;
    t4.tr_color=Color.ORANGE;
    t5.tr_color=Color.ORANGE;
    t6.tr_color=Color.ORANGE;
    t7.tr_color=Color.ORANGE;
    t8.tr_color=Color.ORANGE;
    t9.tr_color=Color.ORANGE;
    
    t1.nr=46;
    t2.nr=47;
    t3.nr=48;
    t4.nr=49;
    t5.nr=50;
    t6.nr=51;
    t7.nr=52;
    t8.nr=53;
    t9.nr=54;
    
    tlist.add(t1);
    tlist.add(t2);
    tlist.add(t3);
    
    tlist.add(t4);
    tlist.add(t5);
    tlist.add(t6);
    
    tlist.add(t7);
    tlist.add(t8);
    tlist.add(t9);
    
    Triangle t1a=new Triangle(new Point3d(-5,5,15),new Point3d(5,5,15),new Point3d(5,-5,15),new Point3d(-5,-5,15),new Point3d(0,0,15));
    Triangle t2a=new Triangle(new Point3d(-5-10,5,15),new Point3d(5-10,5,15),new Point3d(5-10,-5,15),new Point3d(-5-10,-5,15),new Point3d(-10,0,15));
    Triangle t3a=new Triangle(new Point3d(-5+10,5,15),new Point3d(5+10,5,15),new Point3d(5+10,-5,15),new Point3d(-5+10,-5,15),new Point3d(10,0,15));
    
    Triangle t4a=new Triangle(new Point3d(-5,5+10,15),new Point3d(5,5+10,15),new Point3d(5,-5+10,15),new Point3d(-5,-5+10,15),new Point3d(0,10,15));
    Triangle t5a=new Triangle(new Point3d(-5-10,5+10,15),new Point3d(5-10,5+10,15),new Point3d(5-10,-5+10,15),new Point3d(-5-10,-5+10,15),new Point3d(-10,10,15));
    Triangle t6a=new Triangle(new Point3d(-5+10,5+10,15),new Point3d(5+10,5+10,15),new Point3d(5+10,-5+10,15),new Point3d(-5+10,-5+10,15),new Point3d(10,10,15));
    
    Triangle t7a=new Triangle(new Point3d(-5,5-10,15),new Point3d(5,5-10,15),new Point3d(5,-5-10,15),new Point3d(-5,-5-10,15),new Point3d(0,-10,15));
    Triangle t8a=new Triangle(new Point3d(-5-10,5-10,15),new Point3d(5-10,5-10,15),new Point3d(5-10,-5-10,15),new Point3d(-5-10,-5-10,15),new Point3d(-10,-10,15));
    Triangle t9a=new Triangle(new Point3d(-5+10,5-10,15),new Point3d(5+10,5-10,15),new Point3d(5+10,-5-10,15),new Point3d(-5+10,-5-10,15),new Point3d(10,-10,15));
    
    t1a.tr_color=new Color(255,255,0);t1a.nr=1;t1a.nr2=5;
    t2a.tr_color=new Color(255,255,0);t2a.nr=2;t2a.nr2=4;
    t3a.tr_color=new Color(255,255,0);t3a.nr=3;t3a.nr2=6;
    
    t4a.tr_color=new Color(255,255,0);t4a.nr=4;t4a.nr2=2;
    t5a.tr_color=new Color(255,255,0);t5a.nr=5;t5a.nr2=1;
    t6a.tr_color=new Color(255,255,0);t6a.nr=6;t6a.nr2=3;
    
    t7a.tr_color=new Color(255,255,0);t7a.nr=7;t7a.nr2=8;
    t8a.tr_color=new Color(255,255,0);t8a.nr=8;t8a.nr2=7;
    t9a.tr_color=new Color(255,255,0);t9a.nr=9;t9a.nr2=9;
    
    
    
    
    
    
    tlist.add(t1a);
    tlist.add(t2a);
    tlist.add(t3a);
    
    tlist.add(t4a);
    tlist.add(t5a);
    tlist.add(t6a);
    
    tlist.add(t7a);
    tlist.add(t8a);
    tlist.add(t9a);
    
    
    Triangle t1b=new Triangle(new Point3d(-5,-15,5),new Point3d(5,-15,5),new Point3d(5,-15,-5),new Point3d(-5,-15,-5),new Point3d(0,-15,0));
    Triangle t2b=new Triangle(new Point3d(-5-10,-15,5),new Point3d(5-10,-15,5),new Point3d(5-10,-15,-5),new Point3d(-5-10,-15,-5),new Point3d(-10,-15,0));
    Triangle t3b=new Triangle(new Point3d(-5+10,-15,5),new Point3d(5+10,-15,5),new Point3d(5+10,-15,-5),new Point3d(-5+10,-15,-5),new Point3d(10,-15,0));
    
    Triangle t4b=new Triangle(new Point3d(-5,-15,5+10),new Point3d(5,-15,5+10),new Point3d(5,-15,-5+10),new Point3d(-5,-15,-5+10),new Point3d(0,-15,10));
    Triangle t5b=new Triangle(new Point3d(-5-10,-15,5+10),new Point3d(5-10,-15,5+10),new Point3d(5-10,-15,-5+10),new Point3d(-5-10,-15,-5+10),new Point3d(-10,-15,10));
    Triangle t6b=new Triangle(new Point3d(-5+10,-15,5+10),new Point3d(5+10,-15,5+10),new Point3d(5+10,-15,-5+10),new Point3d(-5+10,-15,-5+10),new Point3d(10,-15,10));
    
    Triangle t7b=new Triangle(new Point3d(-5,-15,5-10),new Point3d(5,-15,5-10),new Point3d(5,-15,-5-10),new Point3d(-5,-15,-5-10),new Point3d(0,-15,-10));
    Triangle t8b=new Triangle(new Point3d(-5-10,-15,5-10),new Point3d(5-10,-15,5-10),new Point3d(5-10,-15,-5-10),new Point3d(-5-10,-15,-5-10),new Point3d(-10,-15,-10));
    Triangle t9b=new Triangle(new Point3d(-5+10,-15,5-10),new Point3d(5+10,-15,5-10),new Point3d(5+10,-15,-5-10),new Point3d(-5+10,-15,-5-10),new Point3d(10,-15,-10));
    
    t1b.tr_color=new Color(0,155,0);t1b.nr=10;t1b.nr2=14;
    t2b.tr_color=new Color(0,155,0);t2b.nr=11;t2b.nr2=13;
    t3b.tr_color=new Color(0,155,0);t3b.nr=12;t3b.nr2=15;
    
    t4b.tr_color=new Color(0,155,0);t4b.nr=13;t4b.nr2=11;
    t5b.tr_color=new Color(0,155,0);t5b.nr=14;t5b.nr2=10;
    t6b.tr_color=new Color(0,155,0);t6b.nr=15;t6b.nr2=12;
    
    t7b.tr_color=new Color(0,155,0);t7b.nr=16;t7b.nr2=17;
    t8b.tr_color=new Color(0,155,0);t8b.nr=17;t8b.nr2=16;
    t9b.tr_color=new Color(0,155,0);t9b.nr=18;t9b.nr2=18;
        
    tlist.add(t1b);
    tlist.add(t2b);
    tlist.add(t3b);
    
    tlist.add(t4b);
    tlist.add(t5b);
    tlist.add(t6b);
    
    tlist.add(t7b);
    tlist.add(t8b);
    tlist.add(t9b);
    
    
    Triangle t1c=new Triangle(new Point3d(-5,15,5),new Point3d(5,15,5),new Point3d(5,15,-5),new Point3d(-5,15,-5),new Point3d(0,15,0));
    Triangle t2c=new Triangle(new Point3d(-5-10,15,5),new Point3d(5-10,15,5),new Point3d(5-10,15,-5),new Point3d(-5-10,15,-5),new Point3d(-10,15,0));
    Triangle t3c=new Triangle(new Point3d(-5+10,15,5),new Point3d(5+10,15,5),new Point3d(5+10,15,-5),new Point3d(-5+10,15,-5),new Point3d(10,15,0));
    
    Triangle t4c=new Triangle(new Point3d(-5,15,5+10),new Point3d(5,15,5+10),new Point3d(5,15,-5+10),new Point3d(-5,15,-5+10),new Point3d(0,15,10));
    Triangle t5c=new Triangle(new Point3d(-5-10,15,5+10),new Point3d(5-10,15,5+10),new Point3d(5-10,15,-5+10),new Point3d(-5-10,15,-5+10),new Point3d(-10,15,10));
    Triangle t6c=new Triangle(new Point3d(-5+10,15,5+10),new Point3d(5+10,15,5+10),new Point3d(5+10,15,-5+10),new Point3d(-5+10,15,-5+10),new Point3d(10,15,10));
    
    Triangle t7c=new Triangle(new Point3d(-5,15,5-10),new Point3d(5,15,5-10),new Point3d(5,15,-5-10),new Point3d(-5,15,-5-10),new Point3d(0,15,-10));
    Triangle t8c=new Triangle(new Point3d(-5-10,15,5-10),new Point3d(5-10,15,5-10),new Point3d(5-10,15,-5-10),new Point3d(-5-10,15,-5-10),new Point3d(-10,15,-10));
    Triangle t9c=new Triangle(new Point3d(-5+10,15,5-10),new Point3d(5+10,15,5-10),new Point3d(5+10,15,-5-10),new Point3d(-5+10,15,-5-10),new Point3d(10,15,-10));
    
    t1c.tr_color=new Color(255,255,255);t1c.nr=19;t1c.nr2=32;
    t2c.tr_color=new Color(255,255,255);t2c.nr=20;t2c.nr2=31;
    t3c.tr_color=new Color(255,255,255);t3c.nr=21;t3c.nr2=33;
    
    t4c.tr_color=new Color(255,255,255);t4c.nr=22;t4c.nr2=35;
    t5c.tr_color=new Color(255,255,255);t5c.nr=23;t5c.nr2=34;
    t6c.tr_color=new Color(255,255,255);t6c.nr=24;t6c.nr2=36;
    
    t7c.tr_color=new Color(255,255,255);t7c.nr=25;t7c.nr2=29;
    t8c.tr_color=new Color(255,255,255);t8c.nr=26;t8c.nr2=28;
    t9c.tr_color=new Color(255,255,255);t9c.nr=27;t9c.nr2=30;
    
    tlist.add(t1c);
    tlist.add(t2c);
    tlist.add(t3c);
    
    tlist.add(t4c);
    tlist.add(t5c);
    tlist.add(t6c);
    
    tlist.add(t7c);
    tlist.add(t8c);
    tlist.add(t9c);
    
    Triangle t1d=new Triangle(new Point3d(15,5,-5),new Point3d(15,5,5),new Point3d(15,-5,5),new Point3d(15,-5,-5),new Point3d(15,0,0));
    Triangle t2d=new Triangle(new Point3d(15,5,-5-10),new Point3d(15,5,5-10),new Point3d(15,-5,5-10),new Point3d(15,-5,-5-10),new Point3d(15,0,-10));
    Triangle t3d=new Triangle(new Point3d(15,5,-5+10),new Point3d(15,5,5+10),new Point3d(15,-5,5+10),new Point3d(15,-5,-5+10),new Point3d(15,0,10));
    
    Triangle t4d=new Triangle(new Point3d(15,5-10,-5),new Point3d(15,5-10,5),new Point3d(15,-5-10,5),new Point3d(15,-5-10,-5),new Point3d(15,-10,0));
    Triangle t5d=new Triangle(new Point3d(15,5-10,-5-10),new Point3d(15,5-10,5-10),new Point3d(15,-5-10,5-10),new Point3d(15,-5-10,-5-10),new Point3d(15,-10,-10));
    Triangle t6d=new Triangle(new Point3d(15,5-10,-5+10),new Point3d(15,5-10,5+10),new Point3d(15,-5-10,5+10),new Point3d(15,-5-10,-5+10),new Point3d(15,-10,10));
    
    Triangle t7d=new Triangle(new Point3d(15,5+10,-5),new Point3d(15,5+10,5),new Point3d(15,-5+10,5),new Point3d(15,-5+10,-5),new Point3d(15,10,0));
    Triangle t8d=new Triangle(new Point3d(15,5+10,-5-10),new Point3d(15,5+10,5-10),new Point3d(15,-5+10,5-10),new Point3d(15,-5+10,-5-10),new Point3d(15,10,-10));
    Triangle t9d=new Triangle(new Point3d(15,5+10,-5+10),new Point3d(15,5+10,5+10),new Point3d(15,-5+10,5+10),new Point3d(15,-5+10,-5+10),new Point3d(15,10,10));
    
    t1d.tr_color=new Color(0,0,255);t1d.nr=28;t1d.nr2=41;
    t2d.tr_color=new Color(0,0,255);t2d.nr=29;t2d.nr2=42;
    t3d.tr_color=new Color(0,0,255);t3d.nr=30;t3d.nr2=40;
    
    t4d.tr_color=new Color(0,0,255);t4d.nr=31;t4d.nr2=44;
    t5d.tr_color=new Color(0,0,255);t5d.nr=32;t5d.nr2=45;
    t6d.tr_color=new Color(0,0,255);t6d.nr=33;t6d.nr2=43;
    
    t7d.tr_color=new Color(0,0,255);t7d.nr=34;t7d.nr2=38;
    t8d.tr_color=new Color(0,0,255);t8d.nr=35;t8d.nr2=39;
    t9d.tr_color=new Color(0,0,255);t9d.nr=36;t9d.nr2=37;
    
    tlist.add(t1d);
    tlist.add(t2d);
    tlist.add(t3d);
    
    tlist.add(t4d);
    tlist.add(t5d);
    tlist.add(t6d);
    
    tlist.add(t7d);
    tlist.add(t8d);
    tlist.add(t9d);
    
    Triangle t1e=new Triangle(new Point3d(-15,5,-5),new Point3d(-15,5,5),new Point3d(-15,-5,5),new Point3d(-15,-5,-5),new Point3d(-15,0,0));
    Triangle t2e=new Triangle(new Point3d(-15,5,-5-10),new Point3d(-15,5,5-10),new Point3d(-15,-5,5-10),new Point3d(-15,-5,-5-10),new Point3d(-15,0,-10));
    Triangle t3e=new Triangle(new Point3d(-15,5,-5+10),new Point3d(-15,5,5+10),new Point3d(-15,-5,5+10),new Point3d(-15,-5,-5+10),new Point3d(-15,0,10));
    
    Triangle t4e=new Triangle(new Point3d(-15,5-10,-5),new Point3d(-15,5-10,5),new Point3d(-15,-5-10,5),new Point3d(-15,-5-10,-5),new Point3d(-15,-10,0));
    Triangle t5e=new Triangle(new Point3d(-15,5-10,-5-10),new Point3d(-15,5-10,5-10),new Point3d(-15,-5-10,5-10),new Point3d(-15,-5-10,-5-10),new Point3d(-15,-10,-10));
    Triangle t6e=new Triangle(new Point3d(-15,5-10,-5+10),new Point3d(-15,5-10,5+10),new Point3d(-15,-5-10,5+10),new Point3d(-15,-5-10,-5+10),new Point3d(-15,-10,10));
    
    Triangle t7e=new Triangle(new Point3d(-15,5+10,-5),new Point3d(-15,5+10,5),new Point3d(-15,-5+10,5),new Point3d(-15,-5+10,-5),new Point3d(-15,10,0));
    Triangle t8e=new Triangle(new Point3d(-15,5+10,-5-10),new Point3d(-15,5+10,5-10),new Point3d(-15,-5+10,5-10),new Point3d(-15,-5+10,-5-10),new Point3d(-15,10,-10));
    Triangle t9e=new Triangle(new Point3d(-15,5+10,-5+10),new Point3d(-15,5+10,5+10),new Point3d(-15,-5+10,5+10),new Point3d(-15,-5+10,-5+10),new Point3d(-15,10,10));
    
    t1e.tr_color=new Color(255,0,0);t1e.nr=37;t1e.nr2=50;
    t2e.tr_color=new Color(255,0,0);t2e.nr=38;t2e.nr2=49;
    t3e.tr_color=new Color(255,0,0);t3e.nr=39;t3e.nr2=51;
    
    t4e.tr_color=new Color(255,0,0);t4e.nr=40;t4e.nr2=53;
    t5e.tr_color=new Color(255,0,0);t5e.nr=41;t5e.nr2=52;
    t6e.tr_color=new Color(255,0,0);t6e.nr=42;t6e.nr2=54;
    
    t7e.tr_color=new Color(255,0,0);t7e.nr=43;t7e.nr2=47;
    t8e.tr_color=new Color(255,0,0);t8e.nr=44;t8e.nr2=46;
    t9e.tr_color=new Color(255,0,0);t9e.nr=45;t9e.nr2=48;
    
    tlist.add(t1e);
    tlist.add(t2e);
    tlist.add(t3e);
    
    tlist.add(t4e);
    tlist.add(t5e);
    tlist.add(t6e);
    
    tlist.add(t7e);
    tlist.add(t8e);
    tlist.add(t9e);
    
     for(Triangle t:tlist)
     {
     t.nr3=t.nr2;
     }
     
    }
    
    public static void main(String[] args) {
        RubikCube3D r=new RubikCube3D();
        
        
        r.panel=r;
        
        r.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
       
        
        r.thread=new Thread(r);
        r.thread.start();
        
        r.frame.getContentPane().add(r.panel);
        r.frame.setLocation(500, 300);
        
        r.frame.pack();
        r.frame.show();
    }
    
    public Dimension getPreferredSize(){
        return new Dimension(640, 480);
    }
    
    @Override
    public void run() {
        while(true)
        {
            try{
    
                
                if(rotating==false){
                        if(animation==0){animation++;wall_to_rotate=1;rot_dir=1;rotating=true;}
                        else if(animation==1){animation++;wall_to_rotate=4;rotating=true;}
                        else if(animation==2){animation++;wall_to_rotate=6;rotating=true;}
                        else if(animation==3){animation++;wall_to_rotate=3;rotating=true;}
                        else if(animation==4){animation++;wall_to_rotate=9;rotating=true;}
                        else if(animation==5){animation++;wall_to_rotate=2;rotating=true;}
                        else if(animation==6){animation++;wall_to_rotate=7;rotating=true;}
                        else if(animation==7){animation++;wall_to_rotate=5;rotating=true;}
                }
                
                if(rotating==false)
                {
                        if(animation==8){animation++;rot_dir=-1;wall_to_rotate=5;rotating=true;}
                        else if(animation==9){animation++;wall_to_rotate=7;rotating=true;}
                        else if(animation==10){animation++;wall_to_rotate=2;rotating=true;}
                        else if(animation==11){animation++;wall_to_rotate=9;rotating=true;}
                        else if(animation==12){animation++;wall_to_rotate=3;rotating=true;}
                        else if(animation==13){animation++;wall_to_rotate=6;rotating=true;}
                        else if(animation==14){animation++;wall_to_rotate=4;rotating=true;}
                        else if(animation==15){animation++;wall_to_rotate=1;rotating=true;}
                }
                
                if(rotating==true)
                {
                    if(wall_to_rotate==1) rotate_wall_1();
                    if(wall_to_rotate==2) rotate_wall_2();
                    if(wall_to_rotate==3) rotate_wall_3();
                    if(wall_to_rotate==4) rotate_wall_4();
                    if(wall_to_rotate==5) rotate_wall_5();
                    if(wall_to_rotate==6) rotate_wall_6();
                    if(wall_to_rotate==7) rotate_wall_7();
                    if(wall_to_rotate==8) rotate_wall_8();
                    if(wall_to_rotate==9) rotate_wall_9();
                }
                
                
                
                
                angleX++;if(angleX>=360)angleX=0;
                this.repaint();
                Thread.sleep(10);
            }catch(Exception exc){}
        }
    }

    public void rotate_wall_1()
    {
                rotator++;
                if(rotator==90){
                    rotating=false;
                    rotator=0;
                    //         12 11 10
                    //     43  9  8  7  54
                    //     40  6  5  4  51
                    //     37  3  2  1  48
                    //         36 35 34
                    
                    //         54 51 48
                    //     10  7  4  1  34
                    //     11  8  5  2  35
                    //     12  9  6  3  36
                    //         43 40 37
                    
                    tlist_org=new <Triangle>ArrayList();
                    
                    for(Triangle t:tlist)
                    {
                        Triangle nt=new Triangle(t.v1,t.v2,t.v3,t.v4,t.v5);
                        nt.nr=t.nr;nt.nr2=t.nr2;nt.tr_color=t.tr_color;
                        nt.nr3=t.nr3;
                        tlist_org.add(nt);
                    }
                    
                    
                    if(rot_dir==1){
                        change_nr(9,7);change_nr(8,4);change_nr(7,1);
                        change_nr(7,1);change_nr(4,2);change_nr(1,3);
                        change_nr(1,3);change_nr(2,6);change_nr(3,9);
                        change_nr(3,9);change_nr(6,8);change_nr(9,7);

                        change_nr(12,54);change_nr(11,51);change_nr(10,48);
                        change_nr(54,34);change_nr(51,35);change_nr(48,36);
                        change_nr(34,37);change_nr(35,40);change_nr(36,43);
                        change_nr(37,12);change_nr(40,11);change_nr(43,10);
                    }
                    
                    //         12 11 10
                    //     43  9  8  7  54
                    //     40  6  5  4  51
                    //     37  3  2  1  48
                    //         36 35 34
                    
                    //         37 40 43
                    //     36  3  6  9  12
                    //     35  2  5  8  11
                    //     34  1  4  7  10
                    //         48 51 54
                    
                    if(rot_dir==-1){
                        change_nr(7,9);change_nr(4,8);change_nr(1,7);
                        change_nr(1,7);change_nr(2,4);change_nr(3,1);
                        change_nr(3,1);change_nr(6,2);change_nr(9,3);
                        change_nr(9,3);change_nr(8,6);change_nr(7,9);

                        change_nr(54,12);change_nr(51,11);change_nr(48,10);
                        change_nr(34,54);change_nr(35,51);change_nr(36,48);
                        change_nr(37,34);change_nr(40,35);change_nr(43,36);
                        change_nr(12,37);change_nr(11,40);change_nr(10,43);
                    }
                    
                }
                
    }
    
    public void rotate_wall_2()
    {
                rotator++;
                if(rotator==90){
                    rotating=false;
                    rotator=0;
                    
                    //         15 14 13
                    //     44           53
                    //     41           50
                    //     38           47
                    //         33 32 31
                    
                    //         53 50 47
                    //     13           33
                    //     14           32
                    //     15           31
                    //         44 41 38
                    
                    tlist_org=new <Triangle>ArrayList();
                    
                    for(Triangle t:tlist)
                    {
                        Triangle nt=new Triangle(t.v1,t.v2,t.v3,t.v4,t.v5);
                        nt.nr=t.nr;nt.nr2=t.nr2;nt.tr_color=t.tr_color;
                        nt.nr3=t.nr3;
                        tlist_org.add(nt);
                    }
                    
                    if(rot_dir==1){
                        change_nr(15,53);change_nr(14,50);change_nr(13,47);
                        change_nr(53,31);change_nr(50,32);change_nr(47,33);
                        change_nr(31,38);change_nr(32,41);change_nr(33,44);
                        change_nr(38,15);change_nr(41,14);change_nr(44,13);
                    }
                    
                    if(rot_dir==-1){
                        change_nr(53,15);change_nr(50,14);change_nr(47,13);
                        change_nr(31,53);change_nr(32,50);change_nr(33,47);
                        change_nr(38,31);change_nr(41,32);change_nr(44,33);
                        change_nr(15,38);change_nr(14,41);change_nr(13,44);
                    }
                    
                }
                
    }
    
    public void rotate_wall_3()
    {
                rotator++;
                if(rotator==90){
                    rotating=false;
                    rotator=0;
                    
                    //         18  17  16
                    //     45  21  20  19  52
                    //     42  24  23  22  49
                    //     39  27  26  25  46
                    //         30  29  28
                    
                    //         52  49  46
                    //     16  19  22  25  28
                    //     17  20  23  26  29
                    //     18  21  24  27  30
                    //         30  29  28
                    
                    
                    tlist_org=new <Triangle>ArrayList();
                    
                    for(Triangle t:tlist)
                    {
                        Triangle nt=new Triangle(t.v1,t.v2,t.v3,t.v4,t.v5);
                        nt.nr=t.nr;nt.nr2=t.nr2;nt.tr_color=t.tr_color;
                        nt.nr3=t.nr3;
                        tlist_org.add(nt);
                    }
                    
                    
                    if(rot_dir==1){
                        change_nr(21,19);change_nr(20,22);change_nr(19,25);
                        change_nr(19,25);change_nr(22,26);change_nr(25,27);
                        change_nr(25,27);change_nr(26,24);change_nr(27,21);
                        change_nr(27,21);change_nr(24,20);change_nr(21,19);

                        change_nr(18,52);change_nr(17,49);change_nr(16,46);
                        change_nr(52,28);change_nr(49,29);change_nr(46,30);
                        change_nr(28,39);change_nr(29,42);change_nr(30,45);
                        change_nr(39,18);change_nr(42,17);change_nr(45,16);
                    }
                    
                    if(rot_dir==-1){
                        change_nr(19,21);change_nr(22,20);change_nr(25,19);
                        change_nr(25,19);change_nr(26,22);change_nr(27,25);
                        change_nr(27,25);change_nr(24,26);change_nr(21,27);
                        change_nr(21,27);change_nr(20,24);change_nr(19,21);

                        change_nr(52,18);change_nr(49,17);change_nr(46,16);
                        change_nr(28,52);change_nr(29,49);change_nr(30,46);
                        change_nr(39,28);change_nr(42,29);change_nr(45,30);
                        change_nr(18,39);change_nr(17,42);change_nr(16,45);
                    }
                    
                }
                
    }
    
    public void rotate_wall_4()
    {
                rotator++;
                if(rotator==90){
                    rotating=false;
                    rotator=0;
                    
                    //if(t.nr2>=10&&t.nr2<=18) {rotY=-rotator;}  

                    //if(t.nr2==19||t.nr2==20||t.nr2==21){rotY=-rotator;}
                    //if(t.nr2==43||t.nr2==44||t.nr2==45){rotY=-rotator;}
                    //if(t.nr2==9||t.nr2==8||t.nr2==7){rotY=-rotator;}
                    //if(t.nr2==54||t.nr2==53||t.nr2==52){rotY=-rotator;}

                    //         21  20  19
                    //     45  18  17  16  52
                    //     44  15  14  13  53
                    //     43  12  11  10  54
                    //          9  8  7
                    
                    //         52  53  54
                    //     19  16  13  10  7
                    //     20  17  14  11  8
                    //     21  18  15  12  9
                    //         45  44  43
                    
                    
                    tlist_org=new <Triangle>ArrayList();
                    
                    for(Triangle t:tlist)
                    {
                        Triangle nt=new Triangle(t.v1,t.v2,t.v3,t.v4,t.v5);
                        nt.nr=t.nr;nt.nr2=t.nr2;nt.tr_color=t.tr_color;
                        nt.nr3=t.nr3;
                        tlist_org.add(nt);
                    }
                    
                    
                    if(rot_dir==1){
                        change_nr(18,16);change_nr(17,13);change_nr(16,10);
                        change_nr(16,10);change_nr(13,11);change_nr(10,12);
                        change_nr(10,12);change_nr(11,15);change_nr(12,18);
                        change_nr(12,18);change_nr(15,17);change_nr(18,16);

                        change_nr(43,21);change_nr(44,20);change_nr(45,19);
                        change_nr(21,52);change_nr(20,53);change_nr(19,54);
                        change_nr(52,7);change_nr(53,8);change_nr(54,9);
                        change_nr(7,43);change_nr(8,44);change_nr(9,45);
                    }
                    
                    if(rot_dir==-1){
                        change_nr(16,18);change_nr(13,17);change_nr(10,16);
                        change_nr(10,16);change_nr(11,13);change_nr(12,10);
                        change_nr(12,10);change_nr(15,11);change_nr(18,12);
                        change_nr(18,12);change_nr(17,15);change_nr(16,18);

                        change_nr(21,43);change_nr(20,44);change_nr(19,45);
                        change_nr(52,21);change_nr(53,20);change_nr(54,19);
                        change_nr(7,52);change_nr(8,53);change_nr(9,54);
                        change_nr(43,7);change_nr(44,8);change_nr(45,9);
                    }
                    
                }
                
    }
    
    public void rotate_wall_5()
    {
                rotator++;
                if(rotator==90){
                    rotating=false;
                    rotator=0;
                    
                    //         24 23 22
                    //     42           49
                    //     41           50
                    //     40           51
                    //         6 5 4
                    
                    //         49 50 51
                    //     22           4
                    //     23           5
                    //     24           6
                    //         42 41 40
                    
                    tlist_org=new <Triangle>ArrayList();
                    
                    for(Triangle t:tlist)
                    {
                        Triangle nt=new Triangle(t.v1,t.v2,t.v3,t.v4,t.v5);
                        nt.nr=t.nr;nt.nr2=t.nr2;nt.tr_color=t.tr_color;
                        nt.nr3=t.nr3;
                        tlist_org.add(nt);
                    }
                    
                    if(rot_dir==1){
                        change_nr(24,49);change_nr(23,50);change_nr(22,51);
                        change_nr(49,4);change_nr(50,5);change_nr(51,6);
                        change_nr(4,40);change_nr(5,41);change_nr(6,42);
                        change_nr(40,24);change_nr(41,23);change_nr(42,22);
                    }
                    
                    if(rot_dir==-1){
                        change_nr(49,24);change_nr(50,23);change_nr(51,22);
                        change_nr(4,49);change_nr(5,50);change_nr(6,51);
                        change_nr(40,4);change_nr(41,5);change_nr(42,6);
                        change_nr(24,40);change_nr(23,41);change_nr(22,42);
                    }
                    
                }
                
    }
    
    public void rotate_wall_6()
    {
                rotator++;
                if(rotator==90){
                    rotating=false;
                    rotator=0;
                    
                    //         27  26  25
                    //     39  30  29  28  46
                    //     38  33  32  31  47
                    //     37  36  35  34  48
                    //          3  2  1
                    
                    //         46  47  48
                    //     25  28  31  34  1
                    //     26  29  32  35  2
                    //     27  30  33  36  3
                    //         39  38  37
                    
                    
                    tlist_org=new <Triangle>ArrayList();
                    
                    for(Triangle t:tlist)
                    {
                        Triangle nt=new Triangle(t.v1,t.v2,t.v3,t.v4,t.v5);
                        nt.nr=t.nr;nt.nr2=t.nr2;nt.tr_color=t.tr_color;
                        nt.nr3=t.nr3;
                        tlist_org.add(nt);
                    }
                    
                    
                    if(rot_dir==1){
                        change_nr(30,28);change_nr(29,31);change_nr(28,34);
                        change_nr(28,34);change_nr(31,35);change_nr(34,36);
                        change_nr(34,36);change_nr(35,33);change_nr(36,30);
                        change_nr(36,30);change_nr(33,29);change_nr(30,28);

                        change_nr(27,46);change_nr(26,47);change_nr(25,48);
                        change_nr(46,1);change_nr(47,2);change_nr(48,3);
                        change_nr(1,37);change_nr(2,38);change_nr(3,39);
                        change_nr(37,27);change_nr(38,26);change_nr(39,25);
                    }
                    
                    if(rot_dir==-1)
                    {
                        change_nr(28,30);change_nr(31,29);change_nr(34,28);
                        change_nr(34,28);change_nr(35,31);change_nr(36,34);
                        change_nr(36,34);change_nr(33,35);change_nr(30,36);
                        change_nr(30,36);change_nr(29,33);change_nr(28,30);

                        change_nr(46,27);change_nr(47,26);change_nr(48,25);
                        change_nr(1,46);change_nr(2,47);change_nr(3,48);
                        change_nr(37,1);change_nr(38,2);change_nr(39,3);
                        change_nr(27,37);change_nr(26,38);change_nr(25,39);
                    }
                    
                }
                
    }
    
    public void rotate_wall_7()
    {
                rotator++;
                if(rotator==90){
                    rotating=false;
                    rotator=0;
                    
                    //         18  15  12
                    //     21  45  44  43  9
                    //     24  42  41  40  6
                    //     27  39  38  37  3
                    //         30  33  36
                    
                    //         9   6   3
                    //     12  43  40  37  36
                    //     15  44  41  38  33
                    //     18  45  42  39  30
                    //         21  24  27
                    
                    tlist_org=new <Triangle>ArrayList();
                    
                    for(Triangle t:tlist)
                    {
                        Triangle nt=new Triangle(t.v1,t.v2,t.v3,t.v4,t.v5);
                        nt.nr=t.nr;nt.nr2=t.nr2;nt.tr_color=t.tr_color;
                        nt.nr3=t.nr3;
                        tlist_org.add(nt);
                    }
                    
                    
                    if(rot_dir==1){
                        change_nr(45,43);change_nr(44,40);change_nr(43,37);
                        change_nr(43,37);change_nr(40,38);change_nr(37,39);
                        change_nr(37,39);change_nr(38,42);change_nr(39,45);
                        change_nr(39,45);change_nr(42,44);change_nr(45,43);

                        change_nr(18,9);change_nr(15,6);change_nr(12,3);
                        change_nr(9,36);change_nr(6,33);change_nr(3,30);
                        change_nr(36,27);change_nr(33,24);change_nr(30,21);
                        change_nr(27,18);change_nr(24,15);change_nr(21,12);
                    }
                    
                    if(rot_dir==-1){
                        change_nr(43,45);change_nr(40,44);change_nr(37,43);
                        change_nr(37,43);change_nr(38,40);change_nr(39,37);
                        change_nr(39,37);change_nr(42,38);change_nr(45,39);
                        change_nr(45,39);change_nr(44,42);change_nr(43,45);

                        change_nr(9,18);change_nr(6,15);change_nr(3,12);
                        change_nr(36,9);change_nr(33,6);change_nr(30,3);
                        change_nr(27,36);change_nr(24,33);change_nr(21,30);
                        change_nr(18,27);change_nr(15,24);change_nr(12,21);
                    }
                    
                    
                }
                
    }
    
    public void rotate_wall_8()
    {
                rotator++;
                if(rotator==90){
                    rotating=false;
                    rotator=0;
                    
                    //         17 14 11
                    //     20           8
                    //     23           5
                    //     26           2
                    //         29 32 35
                    
                    //         8 5 2
                    //     11           35
                    //     14           32
                    //     17           29
                    //         20 23 26
                    
                    tlist_org=new <Triangle>ArrayList();
                    
                    for(Triangle t:tlist)
                    {
                        Triangle nt=new Triangle(t.v1,t.v2,t.v3,t.v4,t.v5);
                        nt.nr=t.nr;nt.nr2=t.nr2;nt.tr_color=t.tr_color;
                        nt.nr3=t.nr3;
                        tlist_org.add(nt);
                    }
                    
                    if(rot_dir==1){
                        change_nr(17,8);change_nr(14,5);change_nr(11,2);
                        change_nr(8,35);change_nr(5,32);change_nr(2,29);
                        change_nr(35,26);change_nr(32,23);change_nr(29,20);
                        change_nr(26,17);change_nr(23,14);change_nr(20,11);
                    }
                    
                    if(rot_dir==-1){
                        change_nr(8,17);change_nr(5,14);change_nr(2,11);
                        change_nr(35,8);change_nr(32,5);change_nr(29,2);
                        change_nr(26,35);change_nr(23,32);change_nr(20,29);
                        change_nr(17,26);change_nr(14,23);change_nr(11,20);
                    }
                    
                }
                
    }
    
    public void rotate_wall_9()
    {
                rotator++;
                if(rotator==90){
                    rotating=false;
                    rotator=0;
                    
                    //if(t.nr2>=46&&t.nr2<=54) {rotX=rotator;frame_list.add(t);}  

                    //if(t.nr2==1||t.nr2==4||t.nr2==7){rotX=rotator;frame_list.add(t);}
                    //if(t.nr2==19||t.nr2==22||t.nr2==25){rotX=rotator;frame_list.add(t);}
                    //if(t.nr2==10||t.nr2==13||t.nr2==16){rotX=rotator;frame_list.add(t);}
                    //if(t.nr2==28||t.nr2==31||t.nr2==34){rotX=rotator;frame_list.add(t);}
                    //         16  13  10
                    //     19  52  53  54  7
                    //     22  49  50  51  4
                    //     25  46  47  48  1
                    //         28  31  34
                    
                    //         7  4  1
                    //     10  54  51  48  34
                    //     13  53  50  47  31
                    //     16  52  49  46  28
                    //         10  13  16
                   
                    tlist_org=new <Triangle>ArrayList();
                    
                    for(Triangle t:tlist)
                    {
                        Triangle nt=new Triangle(t.v1,t.v2,t.v3,t.v4,t.v5);
                        nt.nr=t.nr;nt.nr2=t.nr2;nt.tr_color=t.tr_color;
                        nt.nr3=t.nr3;
                        tlist_org.add(nt);
                    }
                    
                    if(rot_dir==1){
                        change_nr(52,54);change_nr(53,51);change_nr(54,48);
                        change_nr(54,48);change_nr(51,47);change_nr(48,46);
                        change_nr(48,46);change_nr(47,49);change_nr(46,52);
                        change_nr(46,52);change_nr(49,53);change_nr(52,54);

                        change_nr(16,7);change_nr(13,4);change_nr(10,1);
                        change_nr(7,34);change_nr(4,31);change_nr(1,28);
                        change_nr(34,25);change_nr(31,22);change_nr(28,19);
                        change_nr(25,16);change_nr(22,13);change_nr(19,10);
                    }
                    
                    if(rot_dir==-1){
                        change_nr(54,52);change_nr(51,53);change_nr(48,54);
                        change_nr(48,54);change_nr(47,51);change_nr(46,48);
                        change_nr(46,48);change_nr(49,47);change_nr(52,46);
                        change_nr(52,46);change_nr(53,49);change_nr(54,52);

                        change_nr(7,16);change_nr(4,13);change_nr(1,10);
                        change_nr(34,7);change_nr(31,4);change_nr(28,1);
                        change_nr(25,34);change_nr(22,31);change_nr(19,28);
                        change_nr(16,25);change_nr(13,22);change_nr(10,19);
                    }
                    
                }
                
    }
    
    public void change_nr(int a,int b)
    {
        Triangle refa=null,refb=null;
        Color cola=null,colb=null;
        
        for(Triangle t:tlist)
        {
            if(t.nr2==a) 
            {
                refa=t;
                cola=t.tr_color;
            }
        }
        
        for(Triangle t2:tlist_org)
        {
            if(t2.nr2==b)
            {
                refb=t2;
                colb=t2.tr_color;
            }
        }
        refa.nr3=refb.nr3;
        refa.tr_color=colb;
    }
  
    
    public void paintComponent(Graphics g){
        
	super.paintComponent(g);
     
        ArrayList<Triangle> frame_list=new ArrayList<Triangle>();
        
        g.setColor(Color.white);
        
        
        
        g.setColor(Color.white);
        //g.setColor(new Color(0,0,255));
        
        
        g.fillRect(0, 0, 640, 480);
        g.setColor(Color.black);
        
        
        int rotX=0;
        int rotY=0;
        int rotZ=0;
        
        int WorldRotX=(int)WorldX;
        int WorldRotY=(int)WorldY;
        for(Triangle t:tlist)
        {
            rotZ=0;rotX=0;rotY=0;
            
            
            if(wall_to_rotate==1){
                if(t.nr2>=1&&t.nr2<=9) {rotZ=rotator*rot_dir;frame_list.add(t);}  

                if(t.nr2==35||t.nr2==36||t.nr2==34){rotZ=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==48||t.nr2==51||t.nr2==54){rotZ=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==43||t.nr2==40||t.nr2==37){rotZ=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==10||t.nr2==11||t.nr2==12){rotZ=rotator*rot_dir;frame_list.add(t);}
            }
            
            if(wall_to_rotate==2){
                
                if(t.nr2==15||t.nr2==14||t.nr2==13){rotZ=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==53||t.nr2==50||t.nr2==47){rotZ=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==31||t.nr2==32||t.nr2==33){rotZ=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==44||t.nr2==41||t.nr2==38){rotZ=rotator*rot_dir;frame_list.add(t);}
            }
            
            if(wall_to_rotate==3){
                if(t.nr2>=19&&t.nr2<=27) {rotZ=rotator*rot_dir;frame_list.add(t);}  

                if(t.nr2==18||t.nr2==17||t.nr2==16){rotZ=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==52||t.nr2==49||t.nr2==46){rotZ=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==28||t.nr2==29||t.nr2==30){rotZ=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==39||t.nr2==42||t.nr2==45){rotZ=rotator*rot_dir;frame_list.add(t);}
            }
            
            if(wall_to_rotate==4){
                if(t.nr2>=10&&t.nr2<=18) {rotY=-rotator*rot_dir;frame_list.add(t);}  

                if(t.nr2==19||t.nr2==20||t.nr2==21){rotY=-rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==43||t.nr2==44||t.nr2==45){rotY=-rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==9||t.nr2==8||t.nr2==7){rotY=-rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==54||t.nr2==53||t.nr2==52){rotY=-rotator*rot_dir;frame_list.add(t);}
            }
            
             if(wall_to_rotate==5){
                
                if(t.nr2==4||t.nr2==5||t.nr2==6){rotY=-rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==40||t.nr2==41||t.nr2==42){rotY=-rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==24||t.nr2==23||t.nr2==22){rotY=-rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==49||t.nr2==50||t.nr2==51){rotY=-rotator*rot_dir;frame_list.add(t);}
            }
             
            if(wall_to_rotate==6){
                if(t.nr2>=28&&t.nr2<=36) {rotY=-rotator*rot_dir;frame_list.add(t);}  

                if(t.nr2==1||t.nr2==2||t.nr2==3){rotY=-rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==37||t.nr2==38||t.nr2==39){rotY=-rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==27||t.nr2==25||t.nr2==26){rotY=-rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==46||t.nr2==47||t.nr2==48){rotY=-rotator*rot_dir;frame_list.add(t);}
            } 
            
            if(wall_to_rotate==7){
                if(t.nr2>=37&&t.nr2<=45) {rotX=rotator*rot_dir;frame_list.add(t);}  

                if(t.nr2==3||t.nr2==6||t.nr2==9){rotX=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==21||t.nr2==24||t.nr2==27){rotX=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==30||t.nr2==33||t.nr2==36){rotX=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==12||t.nr2==15||t.nr2==18){rotX=rotator*rot_dir;frame_list.add(t);}
            } 
            
            if(wall_to_rotate==8){
                
                if(t.nr2==17||t.nr2==14||t.nr2==11){rotX=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==2||t.nr2==5||t.nr2==8){rotX=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==20||t.nr2==23||t.nr2==26){rotX=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==29||t.nr2==32||t.nr2==35){rotX=rotator*rot_dir;frame_list.add(t);}
            }
            
            if(wall_to_rotate==9){
                if(t.nr2>=46&&t.nr2<=54) {rotX=rotator*rot_dir;frame_list.add(t);}  

                if(t.nr2==1||t.nr2==4||t.nr2==7){rotX=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==19||t.nr2==22||t.nr2==25){rotX=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==10||t.nr2==13||t.nr2==16){rotX=rotator*rot_dir;frame_list.add(t);}
                if(t.nr2==28||t.nr2==31||t.nr2==34){rotX=rotator*rot_dir;frame_list.add(t);}
            } 
            
            //if(t.nr==3) {rotZ=45;}
            
            
                                                    Point3d e1=t.v1;
                                                    Point3d e2=t.v2;
                                                    Point3d e3=t.v3;
                                                    Point3d e4=t.v4;
                                                    
                                                    Point3d e5=t.v5;
                                                    
                                                    e1.rotateAxisY(0);e1.rotateAxisX(0);e1.calculate2dpoint();
                                                    e2.rotateAxisY(0);e2.rotateAxisX(0);e2.calculate2dpoint();
                                                    e3.rotateAxisY(0);e3.rotateAxisX(0);e3.calculate2dpoint();
                                                    e4.rotateAxisY(0);e4.rotateAxisX(0);e4.calculate2dpoint();
                                                    
                                                    if(e5!=null)
                                                    {
                                                    e5.rotateAxisY(0);e5.rotateAxisX(0);e5.calculate2dpoint();
                                                    e5.rotateAxisY_character_original(rotY);
                                                    e5.rotateAxisX_character_original(rotX);
                                                    e5.rotateAxisZ_character_original(rotZ);
                                                    //e1.moveCharacter(player_x+lambo.x,player_y+lambo.y,player_z+lambo.z);
                                                    e5.rotateAxisY_character(WorldRotY);
                                                    e5.rotateAxisX_character(WorldRotX);
                                                    e5.calculate2dpoint_character();
                                                    }
                                                    
                                                    
                                                    e1.rotateAxisY_character_original(rotY);
                                                    e1.rotateAxisX_character_original(rotX);
                                                    e1.rotateAxisZ_character_original(rotZ);
                                                    //e1.moveCharacter(player_x+lambo.x,player_y+lambo.y,player_z+lambo.z);
                                                    e1.rotateAxisY_character(WorldRotY);
                                                    e1.rotateAxisX_character(WorldRotX);
                                                    e1.calculate2dpoint_character();
                                                    
                                                    e2.rotateAxisY_character_original(rotY);
                                                    e2.rotateAxisX_character_original(rotX);
                                                    e2.rotateAxisZ_character_original(rotZ);
                                                    //e1.moveCharacter(player_x+lambo.x,player_y+lambo.y,player_z+lambo.z);
                                                    e2.rotateAxisY_character(WorldRotY);
                                                    e2.rotateAxisX_character(WorldRotX);
                                                    e2.calculate2dpoint_character();
                                                    
                                                    e3.rotateAxisY_character_original(rotY);
                                                    e3.rotateAxisX_character_original(rotX);
                                                    e3.rotateAxisZ_character_original(rotZ);
                                                    //e1.moveCharacter(player_x+lambo.x,player_y+lambo.y,player_z+lambo.z);
                                                    e3.rotateAxisY_character(WorldRotY);
                                                    e3.rotateAxisX_character(WorldRotX);
                                                    e3.calculate2dpoint_character();
                                                    
                                                    e4.rotateAxisY_character_original(rotY);
                                                    e4.rotateAxisX_character_original(rotX);
                                                    e4.rotateAxisZ_character_original(rotZ);
                                                    //e1.moveCharacter(player_x+lambo.x,player_y+lambo.y,player_z+lambo.z);
                                                    e4.rotateAxisY_character(WorldRotY);
                                                    e4.rotateAxisX_character(WorldRotX);
                                                    e4.calculate2dpoint_character();
                                                    
                                                    t.z=(t.v1.zro3+t.v2.zro3+t.v3.zro3+t.v4.zro3)/4.0f;
        }
        Collections.sort(tlist);
        for(Triangle t:tlist)
        {
                        
                        
            t.v1.get2dPoint();
            t.v2.get2dPoint();
            t.v3.get2dPoint();
            t.v4.get2dPoint();
            
            if(t.v5!=null) t.v5.get2dPoint();
            
            
            Color col=t.tr_color;
            g.setColor(col);
            Polygon poly=new Polygon();
            poly.addPoint(t.v1.x2d, t.v1.y2d);
            poly.addPoint(t.v2.x2d, t.v2.y2d);
            poly.addPoint(t.v3.x2d, t.v3.y2d);
            poly.addPoint(t.v4.x2d, t.v4.y2d);
            g.fillPolygon(poly);
            
            g.setColor(new Color(0,0,0));
            g.drawLine(t.v1.x2d,t.v1.y2d,t.v2.x2d,t.v2.y2d);
            g.drawLine(t.v2.x2d,t.v2.y2d,t.v3.x2d,t.v3.y2d);
            g.drawLine(t.v3.x2d,t.v3.y2d,t.v4.x2d,t.v4.y2d);
            g.drawLine(t.v4.x2d,t.v4.y2d,t.v1.x2d,t.v1.y2d);
            
            for(Triangle t3:frame_list)
            {
                if(t3.nr3==t.nr3)
                {
                    g.setColor(new Color(0,0,0));
                    
                    g.drawLine(t.v1.x2d+1,t.v1.y2d+1,t.v2.x2d+1,t.v2.y2d+1);
                    g.drawLine(t.v2.x2d+1,t.v2.y2d+1,t.v3.x2d+1,t.v3.y2d+1);
                    g.drawLine(t.v3.x2d+1,t.v3.y2d+1,t.v4.x2d+1,t.v4.y2d+1);
                    g.drawLine(t.v4.x2d+1,t.v4.y2d+1,t.v1.x2d+1,t.v1.y2d+1);
                }
            }
            //if(t.v5!=null) g.drawString(""+t.nr2, t.v5.x2d, t.v5.y2d);
            //if(t.v5!=null) g.drawString(""+t.nr3, t.v5.x2d, t.v5.y2d);
        }
        
        
        
    }
    
    @Override
    public void mouseClicked(MouseEvent me) {
        
    }

    @Override
    public void mousePressed(MouseEvent me) {
        
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        
    }

    @Override
    public void mouseExited(MouseEvent me) {
        
    }

    @Override
    public void mouseDragged(MouseEvent me) {
        
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        
        
        if(e.getY()>old_mouse_y)
                        {
                            
                            this.WorldX=this.WorldX+0.5*mouse_speed_x;
                            //mouse_moved_up=true;
                            
                        }

                        if(e.getY()<old_mouse_y)
                        {
                            
                            this.WorldX=this.WorldX-0.5*mouse_speed_x;
                            //mouse_moved_down=true;
                            
                        }
                        
                        if(e.getX()>old_mouse_x)
                        {
                        this.WorldY=this.WorldY-1*mouse_speed_y;
                        //mouse_moved_right=true;
                        }

                        if(e.getX()<old_mouse_x)
                        {
                        this.WorldY=this.WorldY+1*mouse_speed_y;
                        //mouse_moved_left=true;
                        }
                        
        this.old_mouse_x=e.getX();
        this.old_mouse_y=e.getY();  
    }

    @Override
    public void keyTyped(KeyEvent ke) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        
                if(e.getKeyCode()==49){System.out.println("1");wall_to_rotate=1;}
                if(e.getKeyCode()==50){System.out.println("2");wall_to_rotate=2;}
                if(e.getKeyCode()==51){System.out.println("3");wall_to_rotate=3;}
                if(e.getKeyCode()==52){System.out.println("4");wall_to_rotate=4;}
                if(e.getKeyCode()==53){System.out.println("5");wall_to_rotate=5;}
                if(e.getKeyCode()==54){System.out.println("6");wall_to_rotate=6;}
                if(e.getKeyCode()==55){System.out.println("7");wall_to_rotate=7;}
                if(e.getKeyCode()==56){System.out.println("8");wall_to_rotate=8;}
                if(e.getKeyCode()==57){System.out.println("9");wall_to_rotate=9;}
                
        
        if(rotating==false){
                rot_dir=1;
                if(e.getKeyCode()==107){System.out.println("+");rotating=true;}
                if(e.getKeyCode()==109){System.out.println("-");rot_dir=-1;rotating=true;}
        }
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        
    }

    @Override
    public void mouseWheelMoved(MouseWheelEvent mwe) {
        
    }
    
}
