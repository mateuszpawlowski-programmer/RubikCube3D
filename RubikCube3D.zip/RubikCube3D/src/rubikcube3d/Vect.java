//Mateusz Pawlowski. 3D Software Renderer. 2023.

package rubikcube3d;

/**
 *
 * @author M
 */
public class Vect {
Float x;
Float y;
Float z;

public Vect(float x,float y,float z)
{
this.x=x;
this.y=y;
this.z=z;
}

public static Vect getNormal(Vect v1,Vect v2)
{
    float x1=v1.x;
    float y1=v1.y;
    float z1=v1.z;
    
    float x2=v2.x;
    float y2=v2.y;
    float z2=v2.z;
    
return new Vect(y1*z2-y2*z1, x2*z1-x1*z2, x1*y2 - x2*y1);
}

public static float getDotProduct(Vect v1,Vect v2)
{
    float x1=v1.x;
    float y1=v1.y;
    float z1=v1.z;
    
    float x2=v2.x;
    float y2=v2.y;
    float z2=v2.z;
    return (x1*x2+y1*y2+z1*z2);
}
}
