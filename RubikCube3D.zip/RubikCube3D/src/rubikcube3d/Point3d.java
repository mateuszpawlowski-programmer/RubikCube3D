//Mateusz Pawlowski. 3D Software Renderer. 2023.

package rubikcube3d;

import java.math.BigDecimal;

/**
 *
 * @author M
 */
public class Point3d implements Comparable{

public int scale=4;

Float xo;
Float yo;
Float zo;

Float xro;
Float yro;
Float zro;

Float xro2;
Float yro2;
Float zro2;

Float xro3;
Float yro3;
Float zro3;

Float x;
Float y;
Float z;

Float xr;
Float yr;
Float zr;

Float xr2;
Float yr2;
Float zr2;

Float xr3;
Float yr3;
Float zr3;

Integer x2d;
Integer y2d;

boolean isClipped=false;

boolean isBullet=false;
float speed_x;
float speed_y;
float speed_z;
int bullet_live=0;
boolean isPlayerBullet=false;

Point3d(float x,float y)
{
this.x=x;
this.y=y;
this.z=z;
}

Point3d(float x,float y,float z)
{
this.x=x*scale;
this.y=y*scale;
this.z=z*scale;

this.xo=x*scale;
this.yo=y*scale;
this.zo=z*scale;
}

Point3d get2dPoint()
{
    float d=400;
    float x2=0;
    float y2=0;
    //float q=-598;
    float q=-598;
            
            
            
            int res=256;
            res=320;
            
                if (zr2 + d != 0) {
		//256
                        if (zr2 + d >= 0)
                        {
                                x2 = res + (xr2 * d) / (zr2 + d);
                                y2 = res + (yr2 * d) / (zr2 + d);
                                isClipped=false;
                        }

			if (zr2 + d < 0)
			{
				//x2 = res + (xr2 * d) / (q + (d));
				//y2 = res + (yr2 * d) / (q + (d));
                            //-res=
                            //x2 -res*(zr2+d)= (xr2 * d);
                            //x2 -res*(0)= (xr2 * d);
                            x2 = (xr2 * d);
                            y2 = (yr2 * d);
                            isClipped=true;
			}
		
                }
                else {
		    if (zr2 + d <= 0)
                    {
                           // x2 = res + (xr2 * d) / (q + (d));
                           // y2 = res + (yr2 * d) / (q + (d));
                           x2 = (xr2 * d);
                           y2 = (yr2 * d);
                           isClipped=true;
                    }
                }
                
    
    
    return new Point3d((float)x2,(float)y2);
}

public void moveVectorOriginal(float a,float b,float c)
{
x=x+a;
y=y+b;
z=z+c;
}


public void moveVector(float a,float b,float c)
{
xr2=xr2+a;
yr2=yr2+b;
zr2=zr2+c;
}

public void moveBullet()
{
this.rotateAxisY(0);
this.rotateAxisX(0);
this.calculate2dpoint();
bullet_live++;
x=x+speed_x;
y=y+speed_y;
z=z+speed_z;
}

public void calculate2dpoint()
{
Point3d point=this.get2dPoint();
this.x2d=(int)(point.x*1);
this.y2d=(int)(point.y*1);
}

public void rotateAxisY(double alpha)
{
        alpha = alpha * 3.14 / 180;
        
        //float cy=(float)(R_3D.camera*Math.sin(alpha));
        //float cz=(float)(R_3D.camera*Math.cos(alpha));
            
	float tx = (float)(Math.cos(alpha)*x + Math.sin(alpha)*(z));
	float tz = (float)(-Math.sin(alpha)*x + Math.cos(alpha)*(z));
        
        
        this.yr=y;
        this.xr=tx;
        this.zr=tz;
}

public void rotateAxisX(double alpha)
{
            alpha = alpha * 3.14 / 180;

            //float cy=(float)(R_3D.camera*Math.sin(alpha));
            //float cz=(float)(R_3D.camera*Math.cos(alpha));
            

            float ty = (float)(Math.cos(alpha)*(yr) - Math.sin(alpha)*(zr));
            float tz = (float)(Math.sin(alpha)*(yr) + Math.cos(alpha)*(zr));
            
            this.yr2=ty;
            this.zr2=tz;
        
            this.xr2=xr;
}

     @Override
    public int compareTo(Object o) {
        int wynik=-1;
        if (((Point3d)o).zr2>(this.zr2)) wynik=1;
        
        //System.out.println(((Triangle)o).z);
        //System.out.println(this.z);
        
        return wynik;
    }

 
// character code
public void calculate2dpoint_character()
{
Point3d point=this.get2dPoint_character();
this.x2d=(int)(point.x*1);
this.y2d=(int)(point.y*1);
}

public void rotateAxisY_character_original(double alpha)
{
        alpha = alpha * 3.14 / 180;
        
	float tx = (float)(Math.cos(alpha)*xo + Math.sin(alpha)*zo);
	float tz = (float)(-Math.sin(alpha)*xo + Math.cos(alpha)*zo);
        
        this.yro=yo;
        this.xro=tx;
        this.zro=tz;
}


public void rotateAxisX_character_original(double alpha)
{
        alpha = alpha * 3.14 / 180;
        
	float ty = (float)(Math.cos(alpha)*yro - Math.sin(alpha)*zro);
	float tz = (float)(Math.sin(alpha)*yro + Math.cos(alpha)*zro);
        
        this.yro=ty;
        this.zro=tz;
        
        this.xro=xro;
}

public void rotateAxisZ_character_original(double alpha)
{
        alpha = alpha * 3.14 / 180;
        
	float tx = (float)(Math.cos(alpha)*xro - Math.sin(alpha)*yro);
	float ty = (float)(Math.sin(alpha)*xro + Math.cos(alpha)*yro);
        
        this.yro=ty;
        
        this.zro=zro;
        this.xro=tx;
}

public void rotateAxisY_character(double alpha)
{
        alpha = alpha * 3.14 / 180;
        
	float tx = (float)(Math.cos(alpha)*xro + Math.sin(alpha)*zro);
	float tz = (float)(-Math.sin(alpha)*xro + Math.cos(alpha)*zro);
        
        
        this.yro2=yro;
        this.xro2=tx;
        this.zro2=tz;
}

public void rotateAxisX_character(double alpha)
{
        alpha = alpha * 3.14 / 180;
        
	float ty = (float)(Math.cos(alpha)*yro2 - Math.sin(alpha)*zro2);
	float tz = (float)(Math.sin(alpha)*yro2 + Math.cos(alpha)*zro2);
        
        this.yro3=ty;
        this.zro3=tz;
        
        this.xro3=xro2;
}

Point3d get2dPoint_character()
{
    float d=400;
    float x2=0;
    float y2=0;
    //float q=-598;
    float q=-598;
                
            int res=256;
            res=320;
            
                if (zro3 + d != 0) {
		//256
                        if (zro3 + d >= 0)
                        {
                                x2 = res + (xro3 * d) / (zro3 + d);
                                y2 = res + (yro3 * d) / (zro3 + d);
                        }

			if (zro3 + d < 0)
			{
				//x2 = res + (xr2 * d) / (q + (d));
				//y2 = res + (yr2 * d) / (q + (d));
                            //-res=
                            //x2 -res*(zr2+d)= (xr2 * d);
                            //x2 -res*(0)= (xr2 * d);
                            x2 = (xro3 * d);
                            y2 = (yro3 * d);
                                
			}
		
                }
                else {
		    if (zro3 + d <= 0)
                    {
                           // x2 = res + (xr2 * d) / (q + (d));
                           // y2 = res + (yr2 * d) / (q + (d));
                           x2 = (xro3 * d);
                           y2 = (yro3 * d);
                    }
                }
                
    
    
    return new Point3d((float)x2,(float)y2);
}

public void moveCharacter(float a,float b,float c)
{
xro=xro+a;
yro=yro+b;
zro=zro+c;
}

}
